// ============================================================
// SHADOW ASSISTANT — Supabase Auth + Real-Time Integration
// Replace YOUR_SUPABASE_URL and YOUR_SUPABASE_ANON_KEY below
// ============================================================

import { useState, useEffect, useRef, useCallback } from 'react';
import { createClient } from '@supabase/supabase-js';

// ── CONFIG — paste your credentials here ───────────────────
const SUPABASE_URL = 'https://hxtpretwqcuooytvlwaf.supabase.co';
const SUPABASE_ANON =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh4dHByZXR3cWN1b295dHZsd2FmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAyNTM0MDgsImV4cCI6MjA5NTgyOTQwOH0.9mW1zLdR23qx9CitIOLoViZnV7fSqysO5oWLUg35l-g';
const ANTHROPIC_KEY =
  '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';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON);

// ── DESIGN TOKENS ──────────────────────────────────────────
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=JetBrains+Mono:wght@300;400;500&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #080A0F; --surface: #0D1117; --surface2: #131922;
    --border: rgba(255,255,255,0.06); --border-hi: rgba(255,255,255,0.14);
    --accent: #00E5A0; --accent2: #0AFFE3; --warn: #FF6B35;
    --muted: rgba(255,255,255,0.32); --text: rgba(255,255,255,0.88);
    --text-dim: rgba(255,255,255,0.50);
    --font-ui: 'Syne', sans-serif; --font-mono: 'JetBrains Mono', monospace;
    --radius: 8px; --radius-lg: 16px;
    --glow: 0 0 24px rgba(0,229,160,0.15);
  }
  body { background: var(--bg); color: var(--text); font-family: var(--font-ui); min-height: 100vh; }

  /* AUTH SCREEN */
  .auth-root {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--bg);
    background-image:
      linear-gradient(rgba(0,229,160,0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,229,160,0.03) 1px, transparent 1px);
    background-size: 40px 40px;
  }
  .auth-root::before {
    content: '';
    position: fixed;
    top: -20%;
    left: 50%;
    transform: translateX(-50%);
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(0,229,160,0.07) 0%, transparent 70%);
    pointer-events: none;
  }
  .auth-card {
    position: relative;
    z-index: 1;
    background: var(--surface);
    border: 1px solid var(--border-hi);
    border-radius: var(--radius-lg);
    padding: 40px 36px;
    width: 100%;
    max-width: 380px;
    animation: authIn 0.4s cubic-bezier(0.16,1,0.3,1) both;
  }
  @keyframes authIn {
    from { opacity: 0; transform: translateY(20px) scale(0.97); }
    to   { opacity: 1; transform: translateY(0) scale(1); }
  }
  .auth-logo {
    display: flex; align-items: center; gap: 10px;
    margin-bottom: 32px;
  }
  .auth-logo-icon {
    width: 36px; height: 36px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 8px;
    display: grid; place-items: center;
    font-size: 18px;
  }
  .auth-logo-text { font-size: 20px; font-weight: 800; letter-spacing: 0.04em; text-transform: uppercase; }
  .auth-logo-sub  { font-size: 9px; font-family: var(--font-mono); color: var(--accent); letter-spacing: 0.12em; margin-top: 1px; }
  .auth-title { font-size: 22px; font-weight: 800; margin-bottom: 6px; }
  .auth-sub   { font-size: 12px; font-family: var(--font-mono); color: var(--text-dim); margin-bottom: 28px; }
  .auth-field { margin-bottom: 14px; }
  .auth-label { font-family: var(--font-mono); font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-dim); display: block; margin-bottom: 6px; }
  .auth-input {
    width: 100%; padding: 10px 14px;
    background: var(--surface2); border: 1px solid var(--border-hi);
    border-radius: var(--radius); color: var(--text);
    font-family: var(--font-mono); font-size: 13px;
    outline: none; transition: border-color 0.15s, box-shadow 0.15s;
  }
  .auth-input:focus { border-color: var(--accent); box-shadow: var(--glow); }
  .auth-btn {
    width: 100%; padding: 11px;
    background: var(--accent); color: #000;
    border: none; border-radius: var(--radius);
    font-family: var(--font-ui); font-size: 14px; font-weight: 800;
    cursor: pointer; letter-spacing: 0.04em; text-transform: uppercase;
    transition: opacity 0.15s, transform 0.1s;
    margin-top: 6px;
  }
  .auth-btn:hover:not(:disabled) { opacity: 0.88; }
  .auth-btn:active { transform: scale(0.98); }
  .auth-btn:disabled { opacity: 0.4; cursor: not-allowed; }
  .auth-toggle {
    font-family: var(--font-mono); font-size: 11px; color: var(--text-dim);
    text-align: center; margin-top: 20px; cursor: pointer;
  }
  .auth-toggle span { color: var(--accent); cursor: pointer; }
  .auth-toggle span:hover { text-decoration: underline; }
  .auth-error {
    background: rgba(255,107,53,0.1); border: 1px solid rgba(255,107,53,0.3);
    border-radius: var(--radius); padding: 10px 12px;
    font-family: var(--font-mono); font-size: 11px; color: var(--warn);
    margin-bottom: 14px;
  }
  .auth-success {
    background: rgba(0,229,160,0.08); border: 1px solid rgba(0,229,160,0.25);
    border-radius: var(--radius); padding: 10px 12px;
    font-family: var(--font-mono); font-size: 11px; color: var(--accent);
    margin-bottom: 14px;
  }

  /* APP SHELL */
  .app-root {
    min-height: 100vh;
    background-image:
      linear-gradient(rgba(0,229,160,0.025) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,229,160,0.025) 1px, transparent 1px);
    background-size: 40px 40px;
    position: relative;
  }
  .app-root::before {
    content: '';
    position: fixed; top: -30%; left: 50%; transform: translateX(-50%);
    width: 600px; height: 600px;
    background: radial-gradient(circle, rgba(0,229,160,0.05) 0%, transparent 70%);
    pointer-events: none; z-index: 0;
  }
  .shell { max-width: 1100px; margin: 0 auto; padding: 0 24px; position: relative; z-index: 1; }

  /* TOP BAR */
  .topbar { display: flex; align-items: center; justify-content: space-between; padding: 20px 0 16px; border-bottom: 1px solid var(--border); }
  .logo { display: flex; align-items: center; gap: 10px; }
  .logo-icon { width: 32px; height: 32px; background: linear-gradient(135deg, var(--accent), var(--accent2)); border-radius: 7px; display: grid; place-items: center; font-size: 16px; }
  .logo-text { font-size: 17px; font-weight: 800; letter-spacing: 0.04em; text-transform: uppercase; }
  .logo-sub { font-size: 9px; font-family: var(--font-mono); color: var(--accent); letter-spacing: 0.12em; text-transform: uppercase; margin-top: 1px; }
  .topbar-right { display: flex; align-items: center; gap: 10px; }
  .status-pill { display: flex; align-items: center; gap: 6px; font-family: var(--font-mono); font-size: 11px; color: var(--accent); background: rgba(0,229,160,0.08); border: 1px solid rgba(0,229,160,0.2); border-radius: 20px; padding: 4px 10px; }
  .status-dot { width: 6px; height: 6px; background: var(--accent); border-radius: 50%; animation: pulse 2s ease-in-out infinite; }
  @keyframes pulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.5; transform: scale(0.75); } }
  .user-chip { display: flex; align-items: center; gap: 7px; font-family: var(--font-mono); font-size: 11px; color: var(--text-dim); background: var(--surface); border: 1px solid var(--border-hi); border-radius: 20px; padding: 4px 12px; }
  .btn-ghost { background: none; border: 1px solid var(--border-hi); color: var(--text-dim); font-family: var(--font-mono); font-size: 11px; padding: 5px 12px; border-radius: var(--radius); cursor: pointer; transition: all 0.15s; letter-spacing: 0.06em; }
  .btn-ghost:hover { border-color: var(--warn); color: var(--warn); background: rgba(255,107,53,0.05); }

  /* GRID */
  .main-grid { display: grid; grid-template-columns: 220px 1fr 260px; gap: 16px; margin-top: 20px; min-height: calc(100vh - 160px); }
  .panel { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-lg); overflow: hidden; }
  .panel-header { padding: 14px 16px 10px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
  .panel-title { font-size: 10px; font-family: var(--font-mono); font-weight: 500; letter-spacing: 0.12em; text-transform: uppercase; color: var(--text-dim); }
  .panel-badge { font-family: var(--font-mono); font-size: 10px; background: var(--surface2); border: 1px solid var(--border); border-radius: 4px; padding: 2px 6px; color: var(--text-dim); }

  /* NAV */
  .nav-list { padding: 10px 8px; display: flex; flex-direction: column; gap: 2px; }
  .nav-item { display: flex; align-items: center; gap: 10px; padding: 9px 10px; border-radius: var(--radius); cursor: pointer; transition: all 0.12s; font-size: 13px; font-weight: 600; color: var(--text-dim); position: relative; user-select: none; }
  .nav-item:hover { background: var(--surface2); color: var(--text); }
  .nav-item.active { background: rgba(0,229,160,0.09); color: var(--accent); border: 1px solid rgba(0,229,160,0.15); }
  .nav-item.active::before { content: ''; position: absolute; left: 0; top: 25%; bottom: 25%; width: 2px; background: var(--accent); border-radius: 2px; }
  .nav-icon { font-size: 15px; width: 20px; text-align: center; }
  .nav-count { margin-left: auto; font-family: var(--font-mono); font-size: 10px; background: rgba(255,107,53,0.18); color: var(--warn); border-radius: 10px; padding: 1px 6px; }
  .nav-divider { height: 1px; background: var(--border); margin: 8px 10px; }
  .nav-section-label { font-family: var(--font-mono); font-size: 9px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--muted); padding: 8px 10px 4px; }

  /* COMMAND BAR */
  .command-bar { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 14px 16px; display: flex; align-items: center; gap: 12px; transition: border-color 0.15s; }
  .command-bar:focus-within { border-color: rgba(0,229,160,0.4); box-shadow: var(--glow); }
  .command-prefix { font-family: var(--font-mono); font-size: 14px; color: var(--accent); flex-shrink: 0; }
  .command-input { flex: 1; background: none; border: none; outline: none; color: var(--text); font-family: var(--font-mono); font-size: 13px; caret-color: var(--accent); }
  .command-input::placeholder { color: var(--text-dim); }
  .command-kbd { font-family: var(--font-mono); font-size: 10px; color: var(--text-dim); background: var(--surface2); border: 1px solid var(--border-hi); border-radius: 4px; padding: 2px 7px; flex-shrink: 0; }

  /* TASKS */
  .task-add-bar { display: flex; gap: 8px; padding: 10px 10px 6px; }
  .task-add-input { flex: 1; background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius); padding: 8px 12px; color: var(--text); font-family: var(--font-mono); font-size: 12px; outline: none; transition: border-color 0.15s; }
  .task-add-input:focus { border-color: rgba(0,229,160,0.4); }
  .task-add-input::placeholder { color: var(--text-dim); }
  .task-add-btn { background: rgba(0,229,160,0.12); border: 1px solid rgba(0,229,160,0.25); color: var(--accent); font-family: var(--font-mono); font-size: 12px; padding: 8px 14px; border-radius: var(--radius); cursor: pointer; transition: all 0.15s; white-space: nowrap; }
  .task-add-btn:hover { background: rgba(0,229,160,0.2); }
  .task-list { padding: 4px 8px 10px; display: flex; flex-direction: column; gap: 6px; }
  .task-card { background: var(--surface2); border: 1px solid var(--border); border-radius: 10px; padding: 11px 14px; display: flex; align-items: center; gap: 12px; transition: all 0.14s; animation: slideIn 0.25s ease both; }
  @keyframes slideIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
  .task-card:hover { border-color: var(--border-hi); }
  .task-card.done { opacity: 0.4; }
  .task-card.done .task-name { text-decoration: line-through; }
  .task-check { width: 18px; height: 18px; border: 1.5px solid var(--border-hi); border-radius: 5px; flex-shrink: 0; display: grid; place-items: center; font-size: 11px; transition: all 0.12s; cursor: pointer; }
  .task-check.checked { background: var(--accent); border-color: var(--accent); color: #000; }
  .task-body { flex: 1; min-width: 0; }
  .task-name { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .task-meta { display: flex; gap: 8px; margin-top: 3px; align-items: center; }
  .task-module { font-family: var(--font-mono); font-size: 10px; color: var(--text-dim); }
  .task-del { background: none; border: none; color: var(--text-dim); cursor: pointer; font-size: 14px; padding: 2px 4px; border-radius: 4px; transition: all 0.12s; opacity: 0; }
  .task-card:hover .task-del { opacity: 1; }
  .task-del:hover { color: var(--warn); background: rgba(255,107,53,0.1); }
  .tag { font-family: var(--font-mono); font-size: 9px; letter-spacing: 0.06em; padding: 2px 6px; border-radius: 4px; border: 1px solid; }
  .tag-auto { color: var(--accent2); border-color: rgba(10,255,227,0.25); background: rgba(10,255,227,0.06); }
  .tag-core { color: var(--accent); border-color: rgba(0,229,160,0.25); background: rgba(0,229,160,0.06); }

  /* EVENT LOG */
  .event-log { padding: 8px; display: flex; flex-direction: column; gap: 4px; max-height: 280px; overflow-y: auto; }
  .event-log::-webkit-scrollbar { width: 4px; }
  .event-log::-webkit-scrollbar-thumb { background: var(--border-hi); border-radius: 2px; }
  .event-entry { display: flex; gap: 8px; align-items: flex-start; padding: 6px 8px; border-radius: 6px; animation: fadeIn 0.3s ease both; }
  @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
  .event-entry:hover { background: var(--surface2); }
  .event-time { font-family: var(--font-mono); font-size: 9px; color: var(--text-dim); flex-shrink: 0; padding-top: 1px; min-width: 40px; }
  .event-dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; margin-top: 4px; }
  .event-msg { font-size: 11px; color: var(--text-dim); line-height: 1.45; font-family: var(--font-mono); }
  .event-msg strong { color: var(--text); font-weight: 500; }

  /* PROFILE */
  .profile-card { padding: 16px; }
  .profile-row { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; }
  .avatar { width: 40px; height: 40px; background: linear-gradient(135deg, var(--accent), var(--accent2)); border-radius: 10px; display: grid; place-items: center; font-size: 16px; font-weight: 800; color: #000; flex-shrink: 0; }
  .profile-name { font-size: 14px; font-weight: 700; }
  .profile-email { font-family: var(--font-mono); font-size: 10px; color: var(--text-dim); margin-top: 1px; }
  .profile-stat { background: var(--surface2); border: 1px solid var(--border); border-radius: 8px; padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
  .profile-stat-label { font-family: var(--font-mono); font-size: 10px; color: var(--text-dim); }
  .profile-stat-value { font-family: var(--font-mono); font-size: 13px; font-weight: 500; color: var(--accent); }

  /* LOADING */
  .loading-screen { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: var(--bg); flex-direction: column; gap: 16px; }
  .loading-spinner { width: 32px; height: 32px; border: 2px solid var(--border); border-top-color: var(--accent); border-radius: 50%; animation: spin 0.7s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .loading-text { font-family: var(--font-mono); font-size: 11px; color: var(--text-dim); letter-spacing: 0.1em; }

  /* STATS */
  .stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-top: 0; }
  .stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 14px 16px; display: flex; flex-direction: column; gap: 4px; }
  .stat-label { font-family: var(--font-mono); font-size: 9px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-dim); }
  .stat-value { font-size: 26px; font-weight: 800; line-height: 1; letter-spacing: -0.02em; }
  .stat-delta { font-family: var(--font-mono); font-size: 10px; color: var(--accent); }

  /* TABS */
  .tabs { display: flex; gap: 4px; padding: 10px 12px 0; border-bottom: 1px solid var(--border); }
  .tab { font-family: var(--font-mono); font-size: 11px; letter-spacing: 0.04em; padding: 6px 12px 8px; cursor: pointer; color: var(--text-dim); border-bottom: 2px solid transparent; transition: all 0.12s; border-radius: 4px 4px 0 0; user-select: none; }
  .tab:hover { color: var(--text); }
  .tab.active { color: var(--accent); border-bottom-color: var(--accent); }

  .empty-state { padding: 32px 16px; text-align: center; font-family: var(--font-mono); font-size: 11px; color: var(--text-dim); line-height: 1.6; }

  @media (max-width: 900px) { .main-grid { grid-template-columns: 1fr; } .stats-row { grid-template-columns: repeat(2, 1fr); } }
`;

// ── HELPERS ─────────────────────────────────────────────────
const fmtTime = (d) => {
  const t = new Date(d);
  return `${String(t.getHours()).padStart(2, '0')}:${String(
    t.getMinutes()
  ).padStart(2, '0')}`;
};

const logEvent = async (userId, type, payload = {}, source = 'client') => {
  await supabase
    .from('event_log')
    .insert({ user_id: userId, event_type: type, payload, source });
};

// ── AUTH SCREEN ─────────────────────────────────────────────
function AuthScreen({ onAuth }) {
  const [mode, setMode] = useState('signin'); // signin | signup
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const submit = async () => {
    setError('');
    setSuccess('');
    setLoading(true);
    try {
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { display_name: name || email.split('@')[0] } },
        });
        if (error) throw error;
        setSuccess(
          'Account created! Check your email to confirm, then sign in.'
        );
        setMode('signin');
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        onAuth(data.session);
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <style>{CSS}</style>
      <div className="auth-root">
        <div className="auth-card">
          <div className="auth-logo">
            <div className="auth-logo-icon">◈</div>
            <div>
              <div className="auth-logo-text">Shadow</div>
              <div className="auth-logo-sub">Ambient Assistant</div>
            </div>
          </div>
          <div className="auth-title">
            {mode === 'signin' ? 'Welcome back' : 'Create account'}
          </div>
          <div className="auth-sub">
            {mode === 'signin'
              ? 'sign in to your workspace'
              : 'initialize your shadow instance'}
          </div>

          {error && <div className="auth-error">⚠ {error}</div>}
          {success && <div className="auth-success">✓ {success}</div>}

          {mode === 'signup' && (
            <div className="auth-field">
              <label className="auth-label">Display Name</label>
              <input
                className="auth-input"
                placeholder="your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
          )}
          <div className="auth-field">
            <label className="auth-label">Email</label>
            <input
              className="auth-input"
              type="email"
              placeholder="you@domain.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="auth-field">
            <label className="auth-label">Password</label>
            <input
              className="auth-input"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submit()}
            />
          </div>

          <button
            className="auth-btn"
            onClick={submit}
            disabled={loading || !email || !password}
          >
            {loading ? '...' : mode === 'signin' ? 'Sign In' : 'Create Account'}
          </button>

          <div className="auth-toggle">
            {mode === 'signin' ? (
              <>
                No account?{' '}
                <span
                  onClick={() => {
                    setMode('signup');
                    setError('');
                  }}
                >
                  Create one
                </span>
              </>
            ) : (
              <>
                Have an account?{' '}
                <span
                  onClick={() => {
                    setMode('signin');
                    setError('');
                  }}
                >
                  Sign in
                </span>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

// ── MAIN APP ─────────────────────────────────────────────────
export default function ShadowAssistant() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('tasks');
  const [newTask, setNewTask] = useState('');
  const [cmd, setCmd] = useState('');
  const channelRef = useRef(null);

  // ── Auth listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (!data.session) setLoading(false);
    });
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_, sess) => {
      setSession(sess);
      if (!sess) {
        setProfile(null);
        setTasks([]);
        setEvents([]);
        setLoading(false);
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  // ── Load data when session is ready
  useEffect(() => {
    if (!session) return;
    const uid = session.user.id;

    const load = async () => {
      setLoading(true);
      const [{ data: prof }, { data: tsk }, { data: evts }] = await Promise.all(
        [
          supabase.from('profiles').select('*').eq('id', uid).single(),
          supabase
            .from('tasks')
            .select('*')
            .eq('user_id', uid)
            .order('created_at', { ascending: false }),
          supabase
            .from('event_log')
            .select('*')
            .eq('user_id', uid)
            .order('created_at', { ascending: false })
            .limit(30),
        ]
      );
      setProfile(prof);
      setTasks(tsk || []);
      setEvents(evts || []);
      setLoading(false);
      logEvent(uid, 'SESSION_START', { email: session.user.email });
    };

    load();

    // ── Real-time subscriptions
    channelRef.current = supabase
      .channel(`shadow-${uid}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tasks',
          filter: `user_id=eq.${uid}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT')
            setTasks((p) => [payload.new, ...p]);
          if (payload.eventType === 'UPDATE')
            setTasks((p) =>
              p.map((t) => (t.id === payload.new.id ? payload.new : t))
            );
          if (payload.eventType === 'DELETE')
            setTasks((p) => p.filter((t) => t.id !== payload.old.id));
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'event_log',
          filter: `user_id=eq.${uid}`,
        },
        (payload) => setEvents((p) => [payload.new, ...p.slice(0, 29)])
      )
      .subscribe();

    return () => {
      channelRef.current?.unsubscribe();
    };
  }, [session]);

  const signOut = async () => {
    if (session) await logEvent(session.user.id, 'SESSION_END');
    await supabase.auth.signOut();
  };

  const addTask = async () => {
    if (!newTask.trim() || !session) return;
    const uid = session.user.id;
    await supabase.from('tasks').insert({
      user_id: uid,
      title: newTask.trim(),
      module_ref: 'core',
      status: 'pending',
    });
    await logEvent(uid, 'TASK_CREATED', { title: newTask.trim() });
    setNewTask('');
  };

  const toggleTask = async (task) => {
    const next = task.status === 'done' ? 'pending' : 'done';
    await supabase.from('tasks').update({ status: next }).eq('id', task.id);
    await logEvent(session.user.id, 'TASK_UPDATED', {
      id: task.id,
      status: next,
    });
  };

  const deleteTask = async (id) => {
    await supabase.from('tasks').delete().eq('id', id);
    await logEvent(session.user.id, 'TASK_DELETED', { id });
  };

  const dispatchCmd = async () => {
    if (!cmd.trim() || !session) return;
    await logEvent(
      session.user.id,
      'CMD_DISPATCH',
      { command: cmd.trim() },
      'command_bar'
    );
    setCmd('');
  };

  const eventColor = (type) => {
    if (type?.includes('TASK')) return '#A78BFA';
    if (type?.includes('SESSION')) return '#00E5A0';
    if (type?.includes('CMD')) return '#FF6B35';
    return '#0AFFE3';
  };

  if (loading)
    return (
      <>
        <style>{CSS}</style>
        <div className="loading-screen">
          <div className="loading-spinner" />
          <div className="loading-text">initializing shadow...</div>
        </div>
      </>
    );

  if (!session) return <AuthScreen onAuth={setSession} />;

  const pendingTasks = tasks.filter((t) => t.status !== 'done');
  const doneTasks = tasks.filter((t) => t.status === 'done');
  const initial = (profile?.display_name || '?')[0].toUpperCase();

  return (
    <>
      <style>{CSS}</style>
      <div className="app-root">
        <div className="shell">
          {/* TOP BAR */}
          <div className="topbar">
            <div className="logo">
              <div className="logo-icon">◈</div>
              <div>
                <div className="logo-text">Shadow</div>
                <div className="logo-sub">Ambient Assistant · Live</div>
              </div>
            </div>
            <div className="topbar-right">
              <div className="status-pill">
                <div className="status-dot" />
                SUPABASE LIVE
              </div>
              <div className="user-chip">
                {initial} {profile?.display_name || session.user.email}
              </div>
              <button className="btn-ghost" onClick={signOut}>
                Sign out
              </button>
            </div>
          </div>

          {/* STATS */}
          <div className="stats-row" style={{ marginTop: 16 }}>
            {[
              {
                label: 'Pending Tasks',
                value: pendingTasks.length,
                delta: `${doneTasks.length} done`,
              },
              {
                label: 'Events Logged',
                value: events.length,
                delta: 'real-time',
              },
              { label: 'Realtime', value: 'ON', delta: 'subscribed' },
              { label: 'RLS', value: '✓', delta: 'row-level sec' },
            ].map((s, i) => (
              <div className="stat-card" key={i}>
                <div className="stat-label">{s.label}</div>
                <div className="stat-value">{s.value}</div>
                <div className="stat-delta">{s.delta}</div>
              </div>
            ))}
          </div>

          <div className="main-grid">
            {/* LEFT NAV */}
            <div className="panel" style={{ alignSelf: 'start' }}>
              <div className="panel-header">
                <span className="panel-title">Navigation</span>
              </div>
              <div className="nav-list">
                {[
                  {
                    icon: '◈',
                    label: 'Tasks',
                    id: 'tasks',
                    count: pendingTasks.length || null,
                  },
                  { icon: '⌁', label: 'Events', id: 'events', count: null },
                  { icon: '◻', label: 'Profile', id: 'profile', count: null },
                ].map((item) => (
                  <div
                    key={item.id}
                    className={`nav-item${
                      activeTab === item.id ? ' active' : ''
                    }`}
                    onClick={() => setActiveTab(item.id)}
                  >
                    <span className="nav-icon">{item.icon}</span>
                    {item.label}
                    {item.count > 0 && (
                      <span className="nav-count">{item.count}</span>
                    )}
                  </div>
                ))}
                <div className="nav-divider" />
                <div className="nav-section-label">System</div>
                {[
                  { icon: '⬡', label: 'Modules', id: 'mods' },
                  { icon: '⚙', label: 'Config', id: 'config' },
                ].map((item) => (
                  <div
                    key={item.id}
                    className="nav-item"
                    style={{ opacity: 0.5, cursor: 'not-allowed' }}
                  >
                    <span className="nav-icon">{item.icon}</span>
                    {item.label}
                    <span
                      style={{
                        marginLeft: 'auto',
                        fontFamily: 'var(--font-mono)',
                        fontSize: 9,
                        color: 'var(--text-dim)',
                      }}
                    >
                      soon
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* CENTER */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* COMMAND BAR */}
              <div className="command-bar">
                <span className="command-prefix">shadow›</span>
                <input
                  className="command-input"
                  placeholder="dispatch event · log to db · run automation..."
                  value={cmd}
                  onChange={(e) => setCmd(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && dispatchCmd()}
                />
                <span
                  className="command-kbd"
                  style={{ cursor: cmd ? 'pointer' : 'default' }}
                  onClick={dispatchCmd}
                >
                  ↵ run
                </span>
              </div>

              {/* MAIN PANEL */}
              <div className="panel">
                <div className="tabs">
                  {[
                    { id: 'tasks', label: 'task_queue' },
                    { id: 'events', label: 'event_log' },
                    { id: 'profile', label: 'profile' },
                  ].map((tab) => (
                    <div
                      key={tab.id}
                      className={`tab${activeTab === tab.id ? ' active' : ''}`}
                      onClick={() => setActiveTab(tab.id)}
                    >
                      {tab.label}
                    </div>
                  ))}
                </div>

                {/* TASKS */}
                {activeTab === 'tasks' && (
                  <div>
                    <div className="task-add-bar">
                      <input
                        className="task-add-input"
                        placeholder="new task title..."
                        value={newTask}
                        onChange={(e) => setNewTask(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && addTask()}
                      />
                      <button className="task-add-btn" onClick={addTask}>
                        + Add
                      </button>
                    </div>
                    {tasks.length === 0 ? (
                      <div className="empty-state">
                        No tasks yet.
                        <br />
                        Add one above — it syncs to Supabase instantly.
                      </div>
                    ) : (
                      <div className="task-list">
                        {tasks.map((task) => (
                          <div
                            key={task.id}
                            className={`task-card${
                              task.status === 'done' ? ' done' : ''
                            }`}
                          >
                            <div
                              className={`task-check${
                                task.status === 'done' ? ' checked' : ''
                              }`}
                              onClick={() => toggleTask(task)}
                            >
                              {task.status === 'done' && '✓'}
                            </div>
                            <div className="task-body">
                              <div className="task-name">{task.title}</div>
                              <div className="task-meta">
                                <span className="task-module">
                                  {task.module_ref}
                                </span>
                                <span
                                  className={`tag tag-${
                                    task.module_ref === 'core' ? 'core' : 'auto'
                                  }`}
                                >
                                  {task.status}
                                </span>
                              </div>
                            </div>
                            <button
                              className="task-del"
                              onClick={() => deleteTask(task.id)}
                            >
                              ✕
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* EVENTS */}
                {activeTab === 'events' && (
                  <div className="event-log" style={{ maxHeight: 420 }}>
                    {events.length === 0 ? (
                      <div className="empty-state">
                        No events yet.
                        <br />
                        Events are logged automatically as you use the app.
                      </div>
                    ) : (
                      events.map((ev, i) => (
                        <div key={i} className="event-entry">
                          <span className="event-time">
                            {fmtTime(ev.created_at)}
                          </span>
                          <div
                            className="event-dot"
                            style={{ background: eventColor(ev.event_type) }}
                          />
                          <span className="event-msg">
                            <strong>{ev.event_type}</strong>
                            {ev.payload &&
                              Object.keys(ev.payload).length > 0 &&
                              ' · ' + JSON.stringify(ev.payload).slice(0, 60)}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* PROFILE */}
                {activeTab === 'profile' && profile && (
                  <div className="profile-card">
                    <div className="profile-row">
                      <div className="avatar">{initial}</div>
                      <div>
                        <div className="profile-name">
                          {profile.display_name}
                        </div>
                        <div className="profile-email">{profile.email}</div>
                      </div>
                    </div>
                    {[
                      {
                        label: 'User ID',
                        value: profile.id.slice(0, 16) + '…',
                      },
                      { label: 'Role', value: profile.role },
                      {
                        label: 'Member since',
                        value: new Date(
                          profile.created_at
                        ).toLocaleDateString(),
                      },
                      { label: 'Total Tasks', value: tasks.length },
                      { label: 'Events', value: events.length },
                    ].map((s, i) => (
                      <div key={i} className="profile-stat">
                        <span className="profile-stat-label">{s.label}</span>
                        <span className="profile-stat-value">{s.value}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT — live event stream */}
            <div className="panel" style={{ alignSelf: 'start' }}>
              <div className="panel-header">
                <span className="panel-title">Live Stream</span>
                <span className="panel-badge">{events.length}</span>
              </div>
              <div className="event-log">
                {events.length === 0 ? (
                  <div className="empty-state" style={{ padding: '24px 12px' }}>
                    Waiting for events…
                  </div>
                ) : (
                  events.slice(0, 20).map((ev, i) => (
                    <div key={i} className="event-entry">
                      <span className="event-time">
                        {fmtTime(ev.created_at)}
                      </span>
                      <div
                        className="event-dot"
                        style={{ background: eventColor(ev.event_type) }}
                      />
                      <span className="event-msg">
                        <strong>{ev.event_type}</strong>
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
